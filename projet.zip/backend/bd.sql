DROP DATABASE IF EXISTS hardware_db;
CREATE DATABASE IF NOT EXISTS hardware_db CHARACTER SET utf8mb4;
USE hardware_db;

-- 1. TABLES DE LA HIÉRARCHIE GÉOGRAPHIQUE
CREATE TABLE site (
    idSite SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    adresse VARCHAR(255),
    code_postal CHAR(6),
    localite VARCHAR(100),
    photo VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE local (
    idLocal SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    infoLocal VARCHAR(255),
    idSite SMALLINT UNSIGNED NOT NULL,
    photo VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE rangement (
    idRangement SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    infoRangement VARCHAR(128),
    idLocal SMALLINT UNSIGNED NOT NULL,
    photo VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE niveau (
    idNiveau SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(25) NOT NULL,
    infoNiveau VARCHAR(255),
    idRangement SMALLINT UNSIGNED NOT NULL,
    photo VARCHAR(255)
) ENGINE=InnoDB;

-- 2. TABLES UTILISATEURS ET CATÉGORIES
CREATE TABLE categorie (
    idCategorie SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(25) NOT NULL,
    infoPlus VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE utilisateur (
    idUtilisateur SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nomUtilisateur VARCHAR(25) NOT NULL,
    prenomUtilisateur VARCHAR(15) NOT NULL,
    pseudoUtilisateur VARCHAR(20), 
    role ENUM('admin', 'owner', 'user') NOT NULL,
    login VARCHAR(50) UNIQUE NOT NULL,
    mdp VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE statut_reference (
    idStatut SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

-- 3. TABLE PRINCIPALE DES OBJETS
CREATE TABLE objet (
    idObjet SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    infoRangement VARCHAR(255), 
    photo VARCHAR(255),
    idCategorie SMALLINT UNSIGNED NOT NULL,
    idNiveau SMALLINT UNSIGNED NOT NULL,
    infoPlus TEXT, -- Pour les specs techniques détaillées [cite: 47]
    date_acquisition DATE, -- 
    FK_idUser SMALLINT UNSIGNED NOT NULL,
    idStatut SMALLINT UNSIGNED NOT NULL
) ENGINE=InnoDB;

-- 4. TABLE ASSOCIATIVE POUR LE PRÊT (Relation N-N) 
CREATE TABLE pret (
    idPret SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    idObjet SMALLINT UNSIGNED NOT NULL,
    idEmprunteur SMALLINT UNSIGNED NOT NULL,
    date_debut DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_retour_prevue DATETIME,
    date_retour_reelle DATETIME
) ENGINE=InnoDB;

-- 5. CONTRAINTES
ALTER TABLE local ADD CONSTRAINT FK_Local_Site FOREIGN KEY (idSite) REFERENCES site(idSite) ON DELETE CASCADE;
ALTER TABLE rangement ADD CONSTRAINT FK_Rangement_Local FOREIGN KEY (idLocal) REFERENCES local(idLocal) ON DELETE CASCADE;
ALTER TABLE niveau ADD CONSTRAINT FK_Niveau_Rangement FOREIGN KEY (idRangement) REFERENCES rangement(idRangement) ON DELETE CASCADE;
ALTER TABLE objet 
    ADD CONSTRAINT FK_Objet_Niveau FOREIGN KEY (idNiveau) REFERENCES niveau(idNiveau),
    ADD CONSTRAINT FK_Objet_Categorie FOREIGN KEY (idCategorie) REFERENCES categorie(idCategorie),
    ADD CONSTRAINT FK_Objet_User FOREIGN KEY (FK_idUser) REFERENCES utilisateur(idUtilisateur),
    ADD CONSTRAINT FK_Objet_Statut FOREIGN KEY (idStatut) REFERENCES statut_reference(idStatut);
ALTER TABLE pret 
    ADD CONSTRAINT FK_Pret_Objet FOREIGN KEY (idObjet) REFERENCES objet(idObjet),
    ADD CONSTRAINT FK_Pret_Emprunteur FOREIGN KEY (idEmprunteur) REFERENCES utilisateur(idUtilisateur);